document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('prediction-form');
    
    // UI Elements
    const emptyState = document.getElementById('empty-state');
    const loadingState = document.getElementById('loading-state');
    const resultState = document.getElementById('result-state');
    
    // Result Elements
    const probCircle = document.getElementById('prob-circle');
    const probValue = document.getElementById('prob-value');
    const resTier = document.getElementById('res-tier');
    const resAction = document.getElementById('res-action');
    const resFlag = document.getElementById('res-flag');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        // 1. Show Loading State
        emptyState.classList.add('hidden');
        resultState.classList.add('hidden');
        loadingState.classList.remove('hidden');

        // 2. Gather Data from inputs
        const payload = {
            loan_id: document.getElementById('loan_id').value,
            loan_amount_gbp: parseFloat(document.getElementById('loan_amount_gbp').value),
            outstanding_balance_gbp: parseFloat(document.getElementById('outstanding_balance_gbp').value),
            original_loan_term_months: parseFloat(document.getElementById('original_loan_term_months').value),
            remaining_term_months: parseFloat(document.getElementById('remaining_term_months').value),
            interest_rate_pct: parseFloat(document.getElementById('interest_rate_pct').value),
            vintage_year: parseFloat(document.getElementById('vintage_year').value),
            internal_credit_score: parseFloat(document.getElementById('internal_credit_score').value),
            credit_score_change_last_quarter: parseFloat(document.getElementById('credit_score_change_last_quarter').value),
            bureau_inquiries_last_6m: parseFloat(document.getElementById('bureau_inquiries_last_6m').value),
            days_past_due_current: parseFloat(document.getElementById('days_past_due_current').value),
            missed_payments_last_12m: parseFloat(document.getElementById('missed_payments_last_12m').value),
            months_on_book: parseFloat(document.getElementById('months_on_book').value),
            pd_12m_at_origination_pct: parseFloat(document.getElementById('pd_12m_at_origination_pct').value),
            pd_12m_current_pct: parseFloat(document.getElementById('pd_12m_current_pct').value),
            pd_relative_change_pct: parseFloat(document.getElementById('pd_relative_change_pct').value)
        };

        try {
            // 3. Make API Call to local FastAPI endpoint
            const response = await fetch('/api/v1/predict', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!response.ok) throw new Error('API Request Failed');
            
            const data = await response.json();
            
            // 4. Update UI with brief delay for smoothness
            setTimeout(() => {
                loadingState.classList.add('hidden');
                updateResultUI(data);
                resultState.classList.remove('hidden');
            }, 600);

        } catch (error) {
            console.error("Inference Error:", error);
            alert("Error running inference. Ensure backend is running and data is valid.");
            loadingState.classList.add('hidden');
            emptyState.classList.remove('hidden');
        }
    });

    function updateResultUI(data) {
        const probPct = Math.round(data.migration_probability * 100);
        
        // Determine theme color based on risk
        let color = '#38bdf8'; // Default blue
        let tierClass = 'tier-low';
        
        if (data.migration_probability >= 0.6) {
            color = '#ef4444'; // Red
            tierClass = 'tier-high';
        } else if (data.migration_probability >= 0.3) {
            color = '#f59e0b'; // Orange
            tierClass = 'tier-medium';
        } else {
            color = '#10b981'; // Green
            tierClass = 'tier-low';
        }

        // Animate Circular Progress Bar
        let currentAngle = 0;
        const targetAngle = (probPct / 100) * 360;
        const speed = 2; // Animation speed
        
        const animateCircle = setInterval(() => {
            currentAngle += speed;
            if (currentAngle >= targetAngle) {
                currentAngle = targetAngle;
                clearInterval(animateCircle);
            }
            probCircle.style.background = `conic-gradient(${color} ${currentAngle}deg, rgba(255,255,255,0.05) 0deg)`;
            probCircle.style.boxShadow = `0 0 30px ${color}40`; // Hex alpha
        }, 10);

        // Update Text
        probValue.textContent = `${probPct}%`;
        probValue.style.color = color;
        
        resTier.textContent = data.risk_tier;
        resTier.className = `value ${tierClass}`;
        
        resAction.textContent = data.recommended_action;
        
        resFlag.textContent = data.predicted_migration === 1 ? 'Yes (Stage 2)' : 'No (Stage 1)';
        resFlag.className = `value ${data.predicted_migration === 1 ? 'tier-high' : 'tier-low'}`;
    }
});
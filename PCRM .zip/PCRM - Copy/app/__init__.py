"""
QuantumRisk IFRS 9 SaaS Platform
Enterprise-grade credit risk prediction engine
"""
__version__ = "2.1.0"
__author__ = "SICRSense Team"

from .model_service import IFRS9ModelService
from .monitoring import MetricsManager
from .schemas import LoanInput, PredictionOutput
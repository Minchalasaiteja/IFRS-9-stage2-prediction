import os
import time
import logging
from datetime import datetime
from fastapi import FastAPI, HTTPException, BackgroundTasks, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from prometheus_client import make_asgi_app
import asyncio

from app.schemas import LoanInput, PredictionOutput, BatchPredictionOutput, HealthCheckResponse
from app.model_service import IFRS9ModelService
from app.monitoring import metrics_manager, LATENCY_HISTOGRAM, ACTIVE_WEBSOCKETS
from app.websocket_handler import ws_manager

# Setup directories
for directory in ["static", "templates", "logs", "models"]:
    os.makedirs(directory, exist_ok=True)

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize FastAPI with enhanced configuration
app = FastAPI(
    title="QuantumRisk IFRS 9 SaaS Platform",
    description="Real-time enterprise credit risk prediction engine with WebSocket support",
    version="2.1.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files and templates
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Prometheus metrics endpoint
metrics_app = make_asgi_app()
app.mount("/metrics", metrics_app)

# Global model service
model_service = None
startup_time = datetime.utcnow()

@app.on_event("startup")
async def startup_event():
    """Initialize model and services"""
    global model_service
    try:
        logger.info("Initializing QuantumRisk ML Engine...")
        model_service = IFRS9ModelService()
        logger.info(f"Model v{model_service.model_version} loaded successfully")
    except Exception as e:
        logger.warning(f"Running in simulation mode: {e}")
        model_service = IFRS9ModelService.__new__(IFRS9ModelService)
        model_service.model = None
        model_service.model_version = "simulation"

# =====================================================================
# FRONTEND ROUTES
# =====================================================================

@app.get("/", response_class=HTMLResponse)
async def serve_dashboard(request: Request):
    """Serve the main dashboard"""
    return templates.TemplateResponse(
        request=request,
        name="dashboard.html",
        context={
            "title": "SICRSense | Real-Time IFRS 9 Intelligence",
            "model_version": model_service.model_version if model_service else "simulation",
            "year": datetime.now().year
        }
    )

@app.get("/health", response_model=HealthCheckResponse)
async def health_check():
    """Enhanced health check endpoint"""
    uptime = (datetime.utcnow() - startup_time).total_seconds()
    return HealthCheckResponse(
        status="healthy" if model_service and model_service.model else "degraded",
        model_loaded=model_service.model is not None if model_service else False,
        model_version=model_service.model_version if model_service else None,
        uptime_seconds=uptime,
        predictions_today=metrics_manager.daily_counter
    )

# =====================================================================
# WEBSOCKET ENDPOINT
# =====================================================================

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """Real-time WebSocket connection for live updates"""
    await ws_manager.connect(websocket)
    ACTIVE_WEBSOCKETS.inc()
    
    try:
        while True:
            # Receive client messages (if any)
            data = await websocket.receive_text()
            # Handle client commands
            try:
                command = __import__('json').loads(data)
                if command.get("type") == "ping":
                    await ws_manager.send_personal_message({
                        "type": "pong",
                        "timestamp": datetime.utcnow().isoformat()
                    }, websocket)
            except:
                pass
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)
        ACTIVE_WEBSOCKETS.dec()
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        ws_manager.disconnect(websocket)
        ACTIVE_WEBSOCKETS.dec()

# =====================================================================
# API ENDPOINTS
# =====================================================================

@app.post("/api/v1/predict", response_model=PredictionOutput)
async def predict_single_loan(loan: LoanInput, background_tasks: BackgroundTasks):
    """
    Predict SICR for a single loan with real-time WebSocket broadcast
    """
    start_time = time.time()
    
    try:
        # Run prediction
        results = model_service.predict([loan.model_dump()])
        prediction = results[0]
        
        # Calculate latency
        latency = time.time() - start_time
        prediction["processing_time_ms"] = round(latency * 1000, 2)
        prediction["timestamp"] = datetime.utcnow().isoformat()
        
        # Background tasks
        background_tasks.add_task(metrics_manager.log_prediction, loan.model_dump(), prediction, latency)
        background_tasks.add_task(metrics_manager.record_metrics, prediction["risk_tier"], 
                                 prediction["predicted_migration"], prediction.get("model_version", "2.1.0"))
        
        # Record latency
        LATENCY_HISTOGRAM.observe(latency)
        
        # Broadcast via WebSocket
        background_tasks.add_task(ws_manager.broadcast_prediction, prediction)
        
        return prediction
        
    except Exception as e:
        logger.error(f"Prediction failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/v1/predict/batch", response_model=BatchPredictionOutput)
async def predict_batch_loans(loans: list[LoanInput], background_tasks: BackgroundTasks):
    """Batch prediction endpoint"""
    if not model_service or not model_service.model:
        raise HTTPException(status_code=503, detail="Batch predictions require trained model")
    
    start_time = time.time()
    
    try:
        input_dicts = [loan.model_dump() for loan in loans]
        results = model_service.predict(input_dicts)
        
        total_latency = time.time() - start_time
        
        # Background tasks for batch
        for i, result in enumerate(results):
            background_tasks.add_task(metrics_manager.log_prediction, input_dicts[i], result, total_latency/len(results))
            background_tasks.add_task(metrics_manager.record_metrics, result["risk_tier"], 
                                     result["predicted_migration"])
        
        LATENCY_HISTOGRAM.observe(total_latency)
        
        return BatchPredictionOutput(
            predictions=results,
            batch_size=len(loans),
            total_processing_time_ms=round(total_latency * 1000, 2)
        )
        
    except Exception as e:
        logger.error(f"Batch prediction failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/stats")
async def get_stats():
    """Get real-time prediction statistics"""
    return {
        "daily_predictions": metrics_manager.daily_counter,
        "model_version": model_service.model_version if model_service else "simulation",
        "active_websockets": ws_manager.connection_stats["active_connections"],
        "total_messages_sent": ws_manager.connection_stats["messages_sent"],
        "uptime_hours": round((datetime.utcnow() - startup_time).total_seconds() / 3600, 2)
    }
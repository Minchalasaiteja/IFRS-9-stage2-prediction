import joblib
import pandas as pd
import numpy as np
import logging
import os
from typing import List, Dict, Any, Optional
from functools import lru_cache
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class IFRS9ModelService:
    """Enhanced IFRS 9 Model Service with prediction caching"""
    
    def __init__(self, model_path: str = "models/ifrs9_stage2_model.pkl"):
        self.model_path = model_path
        self.model = None
        self.scaler = None
        self.imputer = None
        self.feature_columns = None
        self.optimal_threshold = 0.5
        self.model_version = "2.1.0"
        self.last_trained = None
        self.prediction_cache = {}
        self.cache_ttl = timedelta(minutes=5)
        self.load_artifacts()

    def load_artifacts(self):
        """Load model artifacts with fallback"""
        if not os.path.exists(self.model_path):
            logger.warning(f"Model not found at {self.model_path}, using simulation mode")
            return
            
        try:
            logger.info(f"Loading IFRS9 artifacts from {self.model_path}")
            artifacts = joblib.load(self.model_path)
            
            self.model = artifacts.get('model')
            self.scaler = artifacts.get('scaler')
            self.imputer = artifacts.get('imputer')
            self.feature_columns = artifacts.get('feature_columns')
            self.optimal_threshold = artifacts.get('optimal_threshold', 0.5)
            self.last_trained = artifacts.get('training_date', datetime.utcnow())
            self.model_version = artifacts.get('model_version', '2.1.0')
            
            logger.info(f"Model v{self.model_version} loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            raise

    def _get_cache_key(self, input_dict: Dict) -> str:
        """Generate cache key from input features"""
        key_features = ['internal_credit_score', 'pd_relative_change_pct', 
                       'days_past_due_current', 'loan_amount_gbp']
        return str({k: input_dict.get(k) for k in key_features})

    def _check_cache(self, cache_key: str) -> Optional[Dict]:
        """Check prediction cache"""
        if cache_key in self.prediction_cache:
            cached = self.prediction_cache[cache_key]
            if datetime.utcnow() - cached['timestamp'] < self.cache_ttl:
                return cached['result']
            else:
                del self.prediction_cache[cache_key]
        return None

    def _update_cache(self, cache_key: str, result: Dict):
        """Update prediction cache"""
        self.prediction_cache[cache_key] = {
            'result': result,
            'timestamp': datetime.utcnow()
        }
        # Clean old cache entries
        if len(self.prediction_cache) > 1000:
            self.prediction_cache.clear()

    def predict(self, input_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Enhanced prediction pipeline with caching"""
        if self.model is None:
            return self._simulate_predictions(input_data)

        results = []
        for i, data in enumerate(input_data):
            cache_key = self._get_cache_key(data)
            cached_result = self._check_cache(cache_key)
            
            if cached_result:
                cached_result['loan_id'] = data.get('loan_id', f'batch_{i}')
                results.append(cached_result)
                continue

            # Process single record
            df = pd.DataFrame([data])
            missing_features = set(self.feature_columns) - set(df.columns)
            for feat in missing_features:
                df[feat] = 0.0
            
            X = df[self.feature_columns].copy()
            X_imputed = self.imputer.transform(X)
            X_scaled = self.scaler.transform(X_imputed)
            
            prob = float(self.model.predict_proba(X_scaled)[:, 1][0])
            prediction = self._format_prediction(data.get('loan_id', f'batch_{i}'), prob)
            
            self._update_cache(cache_key, prediction)
            results.append(prediction)
        
        return results

    def _format_prediction(self, loan_id: str, probability: float) -> Dict[str, Any]:
        """Format prediction result"""
        risk_tiers = ['Very Low', 'Low', 'Medium', 'High', 'Very High']
        tier_index = min(int(probability * 5), 4)
        
        return {
            "loan_id": loan_id,
            "migration_probability": round(probability, 4),
            "predicted_migration": 1 if probability >= self.optimal_threshold else 0,
            "risk_tier": risk_tiers[tier_index],
            "recommended_action": 'Immediate Review' if probability >= 0.6 
                                  else 'Review' if probability >= 0.3 
                                  else 'Monitor',
            "model_version": self.model_version
        }

    def _simulate_predictions(self, input_data: List[Dict]) -> List[Dict]:
        """High-fidelity simulation when model not available"""
        results = []
        for data in input_data:
            is_deteriorating = (
                data.get('internal_credit_score', 700) < 600 or 
                data.get('pd_relative_change_pct', 0) > 80 or 
                data.get('days_past_due_current', 0) > 10 or
                data.get('missed_payments_last_12m', 0) >= 1
            )
            prob = np.random.uniform(0.62, 0.98) if is_deteriorating else np.random.uniform(0.01, 0.27)
            results.append(self._format_prediction(data.get('loan_id', 'sim'), prob))
        return results
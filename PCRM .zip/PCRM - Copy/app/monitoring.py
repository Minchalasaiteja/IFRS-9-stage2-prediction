from prometheus_client import Counter, Histogram, Gauge, Summary
import json
import logging
import os
import time
from datetime import datetime, date
from typing import Dict, Any
import threading

# Prometheus Metrics
PREDICTION_COUNTER = Counter(
    'ifrs9_predictions_total',
    'Total predictions by risk tier and migration status',
    ['risk_tier', 'predicted_migration', 'model_version']
)

LATENCY_HISTOGRAM = Histogram(
    'ifrs9_prediction_latency_seconds',
    'Prediction request latency',
    buckets=[0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0]
)

MODEL_VERSION_GAUGE = Gauge(
    'ifrs9_model_version',
    'Current model version',
    ['version']
)

DAILY_PREDICTIONS = Gauge(
    'ifrs9_daily_predictions',
    'Predictions made today'
)

ACTIVE_WEBSOCKETS = Gauge(
    'ifrs9_active_websockets',
    'Number of active WebSocket connections'
)

class MetricsManager:
    """Enhanced metrics and audit logging"""
    
    def __init__(self):
        self.log_dir = "logs"
        os.makedirs(self.log_dir, exist_ok=True)
        self.daily_counter = 0
        self.daily_date = date.today()
        self._lock = threading.Lock()
        self._setup_loggers()
    
    def _setup_loggers(self):
        """Setup structured logging"""
        # Audit logger
        self.audit_logger = logging.getLogger("audit")
        self.audit_logger.setLevel(logging.INFO)
        audit_handler = logging.FileHandler(f"{self.log_dir}/prediction_audit_log.jsonl")
        audit_handler.setFormatter(logging.Formatter('%(message)s'))
        self.audit_logger.addHandler(audit_handler)
        
        # Performance logger
        self.perf_logger = logging.getLogger("performance")
        self.perf_logger.setLevel(logging.INFO)
        perf_handler = logging.FileHandler(f"{self.log_dir}/performance.log")
        perf_handler.setFormatter(logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        ))
        self.perf_logger.addHandler(perf_handler)
    
    def log_prediction(self, input_data: Dict, prediction: Dict, latency: float):
        """Log prediction with full context"""
        audit_record = {
            "timestamp": datetime.utcnow().isoformat(),
            "latency_ms": round(latency * 1000, 2),
            "input": input_data,
            "output": prediction
        }
        self.audit_logger.info(json.dumps(audit_record))
        
        # Update daily counter
        with self._lock:
            today = date.today()
            if today != self.daily_date:
                self.daily_counter = 0
                self.daily_date = today
            self.daily_counter += 1
            DAILY_PREDICTIONS.set(self.daily_counter)
    
    def record_metrics(self, risk_tier: str, predicted_migration: int, model_version: str = "2.1.0"):
        """Record Prometheus metrics"""
        PREDICTION_COUNTER.labels(
            risk_tier=risk_tier,
            predicted_migration=str(predicted_migration),
            model_version=model_version
        ).inc()
        MODEL_VERSION_GAUGE.labels(version=model_version).set(1)

# Global instance
metrics_manager = MetricsManager()
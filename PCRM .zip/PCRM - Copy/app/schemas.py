from pydantic import BaseModel, Field, ConfigDict, field_validator
from typing import List, Optional, Dict, Any
from datetime import datetime

class LoanInput(BaseModel):
    """Enhanced loan input schema with validation"""
    model_config = ConfigDict(extra='allow', populate_by_name=True)

    loan_id: str = Field(..., min_length=1, max_length=50, description="Unique loan identifier")
    loan_amount_gbp: float = Field(..., gt=0, le=50000000, description="Original loan amount in GBP")
    outstanding_balance_gbp: float = Field(..., ge=0, description="Current outstanding balance")
    original_loan_term_months: float = Field(..., gt=0, le=600, description="Original term in months")
    remaining_term_months: float = Field(..., ge=0, description="Remaining term in months")
    interest_rate_pct: float = Field(..., ge=0, le=100, description="Current interest rate percentage")
    vintage_year: float = Field(..., ge=2000, le=2030, description="Year of origination")
    
    internal_credit_score: float = Field(..., ge=300, le=900, description="Internal behavioral score")
    credit_score_change_last_quarter: float = Field(default=0.0, description="Score change in last quarter")
    bureau_inquiries_last_6m: float = Field(default=0.0, ge=0, le=50, description="Recent credit inquiries")
    
    days_past_due_current: float = Field(default=0.0, ge=0, le=365, description="Current days past due")
    missed_payments_last_12m: float = Field(default=0.0, ge=0, le=12, description="Missed payments in last 12 months")
    months_on_book: float = Field(..., ge=0, description="Age of the loan in months")
    
    pd_12m_at_origination_pct: float = Field(..., ge=0, le=100, description="Original 12-month PD")
    pd_12m_current_pct: float = Field(..., ge=0, le=100, description="Current 12-month PD")
    pd_relative_change_pct: float = Field(..., description="Relative change in PD percentage")

    @field_validator('outstanding_balance_gbp')
    @classmethod
    def balance_not_exceed_loan(cls, v: float, info: Dict[str, Any]) -> float:
        if 'loan_amount_gbp' in info.data and v > info.data['loan_amount_gbp']:
            raise ValueError('Outstanding balance cannot exceed loan amount')
        return v

    @field_validator('remaining_term_months')
    @classmethod
    def term_not_exceed_original(cls, v: float, info: Dict[str, Any]) -> float:
        if 'original_loan_term_months' in info.data and v > info.data['original_loan_term_months']:
            raise ValueError('Remaining term cannot exceed original term')
        return v

class PredictionOutput(BaseModel):
    """Prediction result schema"""
    loan_id: str
    migration_probability: float = Field(..., ge=0, le=1)
    predicted_migration: int = Field(..., ge=0, le=1)
    risk_tier: str
    recommended_action: str
    model_version: str = "2.1.0"
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    processing_time_ms: Optional[float] = None

class BatchPredictionOutput(BaseModel):
    """Batch prediction response"""
    predictions: List[PredictionOutput]
    batch_size: int
    total_processing_time_ms: float

class HealthCheckResponse(BaseModel):
    """Health check response"""
    status: str
    model_loaded: bool
    model_version: Optional[str]
    uptime_seconds: float
    predictions_today: int
from fastapi import WebSocket, WebSocketDisconnect
from typing import List, Dict, Any
import json
import asyncio
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class WebSocketManager:
    """Manage WebSocket connections for real-time updates"""
    
    def __init__(self):
        self.active_connections: List[WebSocket] = []
        self.connection_stats: Dict[str, Any] = {
            "total_connections": 0,
            "active_connections": 0,
            "messages_sent": 0
        }
    
    async def connect(self, websocket: WebSocket):
        """Accept new WebSocket connection"""
        await websocket.accept()
        self.active_connections.append(websocket)
        self.connection_stats["total_connections"] += 1
        self.connection_stats["active_connections"] = len(self.active_connections)
        logger.info(f"WebSocket connected. Active: {self.connection_stats['active_connections']}")
        
        # Send initial connection confirmation
        await self.send_personal_message({
            "type": "connection_established",
            "timestamp": datetime.utcnow().isoformat(),
            "message": "Connected to QuantumRisk real-time feed"
        }, websocket)
    
    def disconnect(self, websocket: WebSocket):
        """Remove WebSocket connection"""
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        self.connection_stats["active_connections"] = len(self.active_connections)
        logger.info(f"WebSocket disconnected. Active: {self.connection_stats['active_connections']}")
    
    async def broadcast_prediction(self, prediction_data: Dict[str, Any]):
        """Broadcast prediction result to all connected clients"""
        message = {
            "type": "prediction_update",
            "timestamp": datetime.utcnow().isoformat(),
            "data": prediction_data
        }
        await self.broadcast(message)
    
    async def broadcast(self, message: Dict[str, Any]):
        """Send message to all connected clients"""
        disconnected = []
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
                self.connection_stats["messages_sent"] += 1
            except Exception as e:
                logger.error(f"Failed to send to WebSocket: {e}")
                disconnected.append(connection)
        
        # Clean up failed connections
        for conn in disconnected:
            self.disconnect(conn)
    
    async def send_personal_message(self, message: Dict[str, Any], websocket: WebSocket):
        """Send message to specific client"""
        try:
            await websocket.send_json(message)
            self.connection_stats["messages_sent"] += 1
        except Exception as e:
            logger.error(f"Failed to send personal message: {e}")
            self.disconnect(websocket)

# Global WebSocket manager instance
ws_manager = WebSocketManager()

import uvicorn
import os
import sys

# Ensure the root directory is in the Python path so local imports work seamlessly
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

if __name__ == "__main__":
    """
    Enterprise-grade production server initialization.
    
    Configured Parameters:
    ----------------------
    - app: Points to the 'app' instance inside the 'app/main.py' file.
    - host: Bound to '127.0.0.1' for local development/on-premise staging.
            (Change to '0.0.0.0' inside a Docker container production environment).
    - port: Exposed on standard web service port 8000.
    - reload: Enabled for development environments to hot-reload on file edits.
    """
    print("=" * 80)
    print("      INITIALIZING QUANTUMRISK IFRS 9 INTELLIGENCE SAAS PLATFORM")
    print("=" * 80)
    print("Initializing directories, mounting frontend components, and loading ML weights...")
    
    uvicorn.run(
        "app.main:app",
        host="127.0.0.1",
        port=8000,
        reload=True,
        log_level="info"
    )
    
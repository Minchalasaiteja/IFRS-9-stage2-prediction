function renderCharts() {
  console.log("Render charts placeholder");
}

window.addEventListener("DOMContentLoaded", renderCharts);

"""
QuantumRisk IFRS 9 SaaS Platform - Entry Point
Enhanced with hot-reload support and production configurations
"""
import uvicorn
import os
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

if __name__ == "__main__":
    # Configuration
    port = int(os.getenv("PORT", 8000))
    host = os.getenv("HOST", "0.0.0.0")
    reload = os.getenv("RELOAD", "true").lower() == "true"
    workers = int(os.getenv("WORKERS", 1))
    
    print(f"""
    ╔═══════════════════════════════════════════╗
    ║   QuantumRisk IFRS 9 SaaS Platform       ║
    ║   Version 2.1.0                          ║
    ║   Starting on {host}:{port}                  ║
    ╚═══════════════════════════════════════════╝
    """)
    
    uvicorn.run(
        "app.main:app",
        host=host,
        port=port,
        reload=reload,
        workers=workers,
        log_level="info",
        access_log=True
    )